package assignment2;

public class Q4posNeg {

    public static void main(String[] args) {

        int num = -15;

        if (num > 0) {
            if (num % 4 == 0) {
                System.out.println("It is a positive number and divisible by 4");
            } else {
                System.out.println("It is a positive number but not divisible by 4");
            }
        } else if (num < 0) {
            if (num % 6 == 0) {
                System.out.println("It is a negative number and divisible by 6");
            } else {
                System.out.println("It is a negative number but not divisible by 6");
            }
        } else { // num == 0
            System.out.println("The number is zero");
        }
    }
}
