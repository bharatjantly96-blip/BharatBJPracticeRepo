package assignment2;

public class Q15sequence {

    public static void main(String[] args) {
    	
      int n = 6;
      int seq =1;
      int i=0;
      
      while(i<=n)
      {
           seq = seq+i;
           i++;
           System.out.print(seq+" ");
      }
      
      

    }
}