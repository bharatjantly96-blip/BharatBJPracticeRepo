package assignment2;

public class Q13checkPrimeDigit {
	
	public static void main(String[] args) {
	
	int num = 12343;

    int count = 0;

    while (num > 0) {
        int digit = num % 10;

      
        if (digit == 2 || digit == 3 || digit == 5 || digit == 7) {
            count++;
        }

        num = num / 10; 
    }

    System.out.println("Count of prime digits: " + count);

}
}

