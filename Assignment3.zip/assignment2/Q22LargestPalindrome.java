package assignment2;

public class Q22LargestPalindrome {

	public static void main(String[] args) {
		
		        int largestPalindrome = 0;

		        for (int i = 100; i <= 1000; i++) {

		            int num = i;
		            int rev = 0;

		            for (; num > 0; num /= 10) {
		                rev = rev * 10 + (num % 10);
		            }

		            if (i == rev && i > largestPalindrome) {
		                largestPalindrome = i;
		            }
		        }

		        System.out.println("Largest Palindrome: " + largestPalindrome);
		    }
		}