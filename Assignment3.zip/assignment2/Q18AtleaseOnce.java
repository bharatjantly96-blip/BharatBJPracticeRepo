package assignment2;

public class Q18AtleaseOnce {

	public static void main(String[] args) {
        int i =1;

		do
		{
			System.out.println("Loop Executed");
		}
		while(i<0);

	}

}
