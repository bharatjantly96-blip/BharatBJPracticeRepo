package assignment2;

public class Q9classifiesVC {

	public static void main(String[] args) {
		
		char ch = 'v';
		
		if(ch>='A' && ch<='Z')
		{
			if (ch=='A' || ch=='E' || ch=='I' || ch=='O' || ch=='U')
			{
				System.out.println("Given alphabet is a Uppercase vowel");
			}
			else
			{
				System.out.println("Given alphabet is a Uppercase consonant");
			}
		}
		
		else
		{
			if(ch>='a' && ch<='z')
			{
				if (ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u')
				{
					System.out.println("Given alphabet is a Lowercase vowel");
				}
				else
				{
					System.out.println("Given alphabet is a Lowercase consonant");
				}
			}
		}

	}

}
