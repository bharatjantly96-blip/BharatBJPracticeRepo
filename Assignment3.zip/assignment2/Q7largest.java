package assignment2;

public class Q7largest {

    public static void main(String[] args) {

        int a = 25;
        int b = 42;
        int c = 18;
        int d = 39;

        
        if (a >= b) {
          
            if (a >= c) {
               
                if (a >= d) {
                    System.out.println("Largest number is: " + a);
                } else {
                    System.out.println("Largest number is: " + d);
                }
            } else {
                
                if (c >= d) {
                    System.out.println("Largest number is: " + c);
                } else {
                    System.out.println("Largest number is: " + d);
                }
            }
        } else {
            
            if (b >= c) {
               
                if (b >= d) {
                    System.out.println("Largest number is: " + b);
                } else {
                    System.out.println("Largest number is: " + d);
                }
            } else {
               
                if (c >= d) {
                    System.out.println("Largest number is: " + c);
                } else {
                    System.out.println("Largest number is: " + d);
                }
            }
        }
    }
}
