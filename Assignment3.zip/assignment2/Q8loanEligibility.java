package assignment2;

public class Q8loanEligibility {

	public static void main(String[] args) {
		
		double salary = 31000;
		int age = 25;
		
		if (age<25)
		{
				System.out.println("You are not eligible");
		}
		
		else
		{
		   if(salary<30000)
		   {
			   System.out.println("Eligible for loan A");
			  
		   }
		   
		   else
		   {
			   
			   if(age>=30)
			   {
				   if(salary>=50000)
				   {
					   System.out.println("Eligible for loan B");
				   }
				   
				   else
				   {
					   System.out.println("You are not eligible");
				   }
			   }
			   else
				   System.out.println("You are not eligible");
		   }
		 
		}
		

	}

}


