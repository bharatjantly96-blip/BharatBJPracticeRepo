package assignment2;

public class Q14Fibo {

	public static void main(String[] args) {
		
		int n = 4 ;

        int a = 0, b = 1;
        int count = 1;

        while (count <= n) {

            if (a > 500) {
                break;
            }

            System.out.print(a + " ");

            int c = a + b;
            a = b;
            b = c;

            count++;

	}
	}
}
