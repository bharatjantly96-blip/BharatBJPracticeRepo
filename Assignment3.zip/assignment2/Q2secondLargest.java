package assignment2;

public class Q2secondLargest {

	public static void main(String[] args) {
	
		int a=50;
		int b=33; 
		int c=30;
		
		if ((a>b && a<c) || (a>c && a<b))
		{
		  System.out.println(a);
		}
		
		else if((b>a && b<c) || (b>c && b<a))
		{
			System.out.println(b);
		}

		else
		{
			System.out.println(c);
		}
	}

}
