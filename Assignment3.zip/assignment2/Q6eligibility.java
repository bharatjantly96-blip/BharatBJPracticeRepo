package assignment2;

public class Q6eligibility {

	public static void main(String[] args) {
		
		int Math = 69;
		int Physics = 50;
		int Chemistry = 67;
		
		if ((Math+Physics+Chemistry>=180) || (Math+Physics >= 120))
		{
			System.out.println("You are eligible");
		}
		
		else
		{
			System.out.println("You are not eligible");
		}
		
	}

}
