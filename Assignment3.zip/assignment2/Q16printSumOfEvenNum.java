package assignment2;

import java.util.Scanner;

public class Q16printSumOfEvenNum {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int num;
		int sum=0;
		
		System.out.println("Enter the number (stop at negative number)");
				
		do 
		{
			num = sc.nextInt();
			
			if (num>=0 && num%2==0)
			{
				sum+=num;
			}	
		}
		
		while(num>=0);
		{
     		System.out.println("Sum of even numbers"+ sum);
     		sc.close();
		}
			
	}
}
