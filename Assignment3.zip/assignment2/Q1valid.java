package assignment2;

public class Q1valid {

	public static void main(String[] args) {
			
			for(int i=50; i<=200; i++)
			{
				
				if (i%3==0 && i%5!=0 && i>=50 && i<=200)
				{
					System.out.println("VALID");
				}
				
				else
				{
					System.out.println("INVALID");
				}
				
			}
		
		
	}

}
