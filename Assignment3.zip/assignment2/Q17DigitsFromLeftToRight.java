package assignment2;

public class Q17DigitsFromLeftToRight {

	public static void main(String[] args) {
		
		int num = 54321;
		int temp= num;
		int divisor=1;
		
		do {
			divisor*=10;
			temp/=10;		
		}
		while(temp!=0);
		
		divisor/=10;
		
		do{
			int digit = num/divisor;
			System.out.print(digit+" ");
			num = num%divisor;
			divisor/=10;
		}		
		while(num!=0);	
	}

}
