package assignment2;

public class Q5div {

	public static void main(String[] args) {
		
        int num =10;
        
       if (num % 2==0)
       {
    	   if (num % 3==0)
    	   {
    		   System.out.println("A");
    	   }
    	   
    	   else
    	   {
    		   System.out.println("C");
    	   }
       }
       
       else
       {
    	   if(num % 3==0)
    	   {
    		   System.out.println("B");
    	   }
    	   
    	   else
    	   {
    		   System.out.println("D");
    	   }
       }
		
	}

}
