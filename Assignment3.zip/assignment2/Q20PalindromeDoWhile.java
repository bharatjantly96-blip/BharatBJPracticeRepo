package assignment2;

import java.util.Scanner;

public class Q20PalindromeDoWhile {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int num = sc.nextInt();

        int temp = num;
        int divisor = 1;

        do {
            divisor *= 10;
            temp /= 10;
        } while (temp != 0);

        divisor /= 10;

        boolean isPalindrome = true;

        do {
            int left = num / divisor;
            int right = num % 10;       

            if (left != right) {
                isPalindrome = false;
                break;
            }

            num = (num % divisor) / 10;
            divisor /= 100;

        } while (num > 0 && divisor > 0);

        if (isPalindrome) {
            System.out.println("Palindrome");
        } else {
            System.out.println("Not Palindrome");
        }

        sc.close();
    }
}
