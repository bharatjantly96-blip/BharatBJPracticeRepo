package assignment2;

public class Q11numbersWithWhileLoop {

	public static void main(String[] args) {
		
		int num=1;
		
		while(num<=100)
		{
			if(num==77)
			{
				return;
			}
			
			if(num%3==0 && num%5==0)
			{
				num++;
			  continue;
		
			}
		
			System.out.print(num+" ");	
			num++;

		
		}
		
	}

}
