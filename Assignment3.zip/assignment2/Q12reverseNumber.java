package assignment2;

public class Q12reverseNumber {

	public static void main(String[] args) {
		int num = 1233;

        int reversed = 0;

        while (num > 0) {
            int digit = num % 10;

            if (digit == 0) {
                break;
            }

            reversed = reversed * 10 + digit;
            num = num / 10;
        }

        System.out.println("Reversed number: " + reversed);

	}

}
