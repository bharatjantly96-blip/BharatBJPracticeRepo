package assignment2;

public class Q10sumOfThreeDigits {

	public static void main(String[] args) {
		
		int num = 934;
		int sum;
		
		if(num>99 && num<1000)
		{
			sum = (num/100) + (num/10%10) + (num%10);
					
			 if (sum % 2==0)
			 {
				 System.out.println("It is a 3-digit number and the sum of digits is Even");
					
			 }
			 else
			 {
				 System.out.println("It is a 3-digit number and the sum of digits is odd");
			 }
			 System.out.println(sum);
 		}
		
		else
		{
			System.out.println("It is not a 3-digit number");
		}


	}

}
