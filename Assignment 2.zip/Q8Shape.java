package assignment;

class Shape{
	
	void area() {
		System.out.println("The is shape");
	}
}
	
class Rectangle extends Shape
{
	void area(){
		System.out.println("This is rectange");
	}
}

class Circle extends Shape
{
	void area(){
		System.out.println("This is circle");
	}
}

public class Q8Shape {

	public static void main(String[] args) {
		
		Shape s = new Rectangle();
		s.area();
		
		Shape s1 = new Circle();
		s1.area();


	}

}
