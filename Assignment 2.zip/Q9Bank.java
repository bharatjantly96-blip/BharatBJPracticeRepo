package assignment;

class Bank
{
	final String IFSC="Bank";
	
	final void showIFSC()
	{
		System.out.println("This is IFSC bank");
	}
}

class HDFCBank extends Bank
{
	/*void showIFSC()
	{
		System.out.println("This is from HDFCBank");
	}
*/
}

public class Q9Bank {

	public static void main(String[] args) {
		HDFCBank bk = new HDFCBank();
		bk.showIFSC();

	}

}
