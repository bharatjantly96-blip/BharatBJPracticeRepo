package assignment;

public class Q1Employee {
	
	private int empId;
	private String empName;
	private double salary;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	void displayDetails() {
		System.out.println("Employee id is: "+ empId);
		System.out.println("Employee name is: "+ empName);
		System.out.println("Employee salary is: "+ salary);
		
	}
	
	public static void main(String[] args) {
		
		Q1Employee obj = new Q1Employee();
		obj.setEmpId(101);
		obj.setEmpName("Rahul");
		obj.setSalary(10000.00);
		
		obj.displayDetails();

	}

}
