package assignment;

public class Q3Product {

	int productId;
	String productName;
	float price;
	
	Q3Product()
	{
      System.out.println("Product Created");
	}
	
	Q3Product(int pId, String pName, float pPrice)
	{
      this.productId=pId;
      this.productName=pName;
      this.price=pPrice;
	}
	
	void displayProduct()
	{
		System.out.println("Product id is: "+productId);
		System.out.println("Product name is: "+productName);
		System.out.println("Product price is: "+price);
	}
	
	public static void main(String[] args) {
	
		Q3Product obj = new Q3Product();
		Q3Product obj1 = new Q3Product(23211, "TV", 23999);
		obj1.displayProduct();
		
	}

}
