package assignment;

class Mall{
	
	String Mallname;
	
	Mall()
	{
		System.out.println("Welcome to the Mall");
	}
	Mall (String name)
	{
		this();
		this.Mallname=name;
		
	}
}

public class Q23Mall {

	public static void main(String[] args) {
		
       Mall m = new Mall("Orion");
	}

}
