package assignment;

class LoanCalculator
{
	int amount;
	double interestRate;
	
	void calculateLoan(int amount)
	{
		this.amount = amount;
		System.out.println("Loan amount: "+amount);
		System.out.println("Loan interest rate: "+interestRate);
		System.out.println("____________________________");
	}

	void calculateLoan(int amount, double interestRate)
	{
		this.amount = amount;
		this.interestRate = interestRate;
		System.out.println("Loan amount: "+amount);
		System.out.println("Loan interest rate: "+interestRate);
		
	}
}


public class Q15Calculator {

	public static void main(String[] args) {

		LoanCalculator lc = new LoanCalculator();
		lc.calculateLoan(29000);
		lc.calculateLoan(17000, 7.99);
	}

}
