package assignment;

class GovernmentRules 
{
	final float MAX_WORKING_HOURS = 8;
}

public class Q22Final {

	public static void main(String[] args) {
		
		GovernmentRules gv = new GovernmentRules();
	//	gv.MAX_WORKING_HOURS=7;
	}

}
