package assignment;

abstract class Employee
{
	String empName;
	int empId;
	
	Employee(String name, int id)
	{
		this.empName=name;
		this.empId=id;
	}
	
	abstract void calculateSalary();
	
	void employeeDetails()
	{
		System.out.println("Employee name is: "+empName);
		System.out.println("Employee Id is: "+empId);
	}
}	
class FullTimeEmployee extends Employee
{
	
	FullTimeEmployee(String name, int id)
	{
		super(name, id);

	}
	void calculateSalary()
	{
		System.out.println("Salary is: Per hour salary * 8hours");
	}
}

class PartTimeEmployee extends Employee
{
	PartTimeEmployee(String name, int id)
	{
		super(name, id);

	}
	
	void calculateSalary()
	{
		System.out.println("Salary is: Per hour salary * 4hours");
	}
}


public class Q17Abstract {

	public static void main(String[] args)
	{
		Employee e = new FullTimeEmployee("Bharat", 780000);
		e.employeeDetails();
		e.calculateSalary();
		
		Employee e1 = new PartTimeEmployee("Bharat BJ", 7800);
		e1.employeeDetails();
		e1.calculateSalary();
	}
}
