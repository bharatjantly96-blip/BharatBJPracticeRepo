package assignment;

class School2
{
	 String name;
	 String address;
	 String strength;
	 
	 School2(String name, String address){
		 this.name=name;
		 this.address= address;	 
	 }
	 
	 School2(String name, String address, String strength){
		 this.name=name;
		 this.address=address;
		 this.strength=strength;
	 }
	 
	 void display()
	 {
		 System.out.println("Name is: "+name);
		 System.out.println("Address is: "+address);
		 System.out.println("Strength is: "+strength);
		 System.out.println("__________________");
	 }
}

public class Q26School {

	public static void main(String[] args) {
		School2 sc1 = new School2("School1", "Indranagar");
		sc1.display();
		School2 sc2 = new School2("School2","Rammurthynagar","Competative");
		sc2.display();
		
	}

}
