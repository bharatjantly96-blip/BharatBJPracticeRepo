package assignment;

class ShapeQ{
	float length;
	
	void square()
	{
		double area = length * length;
        System.out.println("Area of Square: " + area);
	}
	
	void rectangle(double breadth)
	{
		double area = length * breadth;
        System.out.println("Area of Rectangle: " + area);
	}
	
	void circle()
	{
		double area = 3.14 * length * length;
        System.out.println("Area of Circle: " + area);
	}
}

public class Q24Shape {

	public static void main(String[] args) {
		
		ShapeQ s = new ShapeQ();
		s.length = 4;
		
		s.square();
		s.rectangle(5.5);
		s.circle();

	}

}
