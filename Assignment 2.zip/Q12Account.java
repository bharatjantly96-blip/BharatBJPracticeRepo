package assignment;

class Account{
	private String accountHolderName;
	private float balance;
	
	public String getAccountHolderName() {
		return accountHolderName;
	}
	
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	
	public float getBalance() {
		return balance;
	}
	
	public void setBalance(float balance) {
		
		if (balance<0)
		{
		System.out.println("Please do not enter negative number");
		}
		else
		{
			this.balance = balance;
		}
		
	}
	
}

public class Q12Account {

	public static void main(String[] args) {
	
		Account ac = new Account();
		ac.setAccountHolderName("Bharat BJ");
	    ac.setBalance(9);
	    System.out.println(ac.getAccountHolderName());
	    System.out.println(ac.getBalance());
	    
	}

}
