package assignment;

public class Q4Calculator {
	
	int add(int a, int b)
	{
		return a+b;
	}
	
	double add(double a, double b)
	{
		return a+b;
	}

	public static void main(String[] args) {
			
      Q4Calculator obj = new Q4Calculator();
      System.out.println(obj.add(10, 7));
      System.out.println(obj.add(12.7, 22));
      
	}

}
