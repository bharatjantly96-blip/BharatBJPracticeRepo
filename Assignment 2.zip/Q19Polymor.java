package assignment;

class Camera{
	void capture()
	{
		System.out.println("This is a camera");
	}
}

class DSLCamera extends Camera
{
	void capture()
	{
		System.out.println("This is a DSLCamera");
	}
}

public class Q19Polymor {

	public static void main(String[] args) {
		
		Camera cr = new DSLCamera();
		cr.capture();

	}

}
