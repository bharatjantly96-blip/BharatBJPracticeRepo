package assignment;

class CStudent
{
	static String collegeName="Dayananda sagar";
	String name;
	int rollNo;
	
	CStudent(String name, int rollNo) {
	    this.name = name;
	    this.rollNo = rollNo;
	}
	
	void display()
	{
		System.out.println("College name is: "+collegeName);
		System.out.println("Student name is: "+name);
		System.out.println("Student roll number is: "+rollNo);
		System.out.println("----------------------");
	}
		
}

public class Q10Student {

	public static void main(String[] args) {
		
		CStudent s1 = new CStudent("Alice", 101);
		CStudent s2 = new CStudent("Bob", 102);
		CStudent s3 = new CStudent("Charlie", 103);
        
        s1.display();
        s2.display();
        s3.display();
        
        CStudent.collegeName = "XYZ College";
        System.out.println("After changing college name:");
        
        s1.display();
        s2.display();
        s3.display();

		
	}

}
