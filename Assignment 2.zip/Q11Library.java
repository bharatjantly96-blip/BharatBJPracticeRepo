package assignment;

class Library
{
	String libraryName;
	
	Library()
	{
		System.out.println("Welcome to the Library!");
	}
	
	void showLocation()
	{
		System.out.println("This library is located in Mumbai");
	}
}

public class Q11Library {

	public static void main(String[] args) {
		
		Library l = new Library();
		l.showLocation();
	}

}
