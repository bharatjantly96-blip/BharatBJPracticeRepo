package assignment;

abstract class Animal{
	
	abstract void sound();
}

class Dog extends Animal
{
	void sound()
	{
		System.out.println("Bow bow");
	}
}

class Cat extends Animal
{
	void sound()
	{
		System.out.println("Mewo mewo");
	}
}

public class Q5Animal {

	public static void main(String[] args) {
	
		Dog d = new Dog();
		d.sound();
		Cat c = new Cat();
		c.sound();

	}
}
