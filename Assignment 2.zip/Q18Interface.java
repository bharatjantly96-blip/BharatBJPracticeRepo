package assignment;

interface Transport
{
	void booking();
}

class Bus implements Transport
{
	public void booking()
	{
		System.out.println("This is bus service");
	}
}

class Flight implements Transport
{
	public void booking()
	{
		System.out.println("This is flight service");
	}
	
}

public class Q18Interface {

	public static void main(String[] args) {
	
		Transport tr = new Bus();
		tr.booking();
		Transport tr1 = new Flight();
		tr1.booking();
		
	}

}
