package assignment;

class Course{
	void courseInfo()
	{
		System.out.println("____Your course_____");
	}
}

class Science extends Course{
	void courseInfo()
	{
		System.out.println("Your course_____Science");
	}
}

class Commerce extends Course
{
	void courseInfo()
	{
		System.out.println("Your course_____Commerce");
	}
}
class Arts extends Course
{
	void courseInfo()
	{
		System.out.println("Your course_____Arts");
	}
}

public class Q14HInherit {

	public static void main(String[] args) {
		
		Course c = new Course();
		c.courseInfo();
		Science s = new Science();
		s.courseInfo();
		Commerce com = new Commerce();
		com.courseInfo();
		Arts a = new Arts();
		a.courseInfo();

	}

}
