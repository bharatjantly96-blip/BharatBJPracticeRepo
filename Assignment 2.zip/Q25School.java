package assignment;

class School{
	String name;
	
	School()
	{
		name = "St. Xavier's School";
		System.out.println("The school name is: "+ name);
	}
	
	void display()
	{
		System.out.println("This School is based out of Kolkata");
	}
}

public class Q25School {

	public static void main(String[] args) {

	   School s = new School();
	   s.display();
	}

}
