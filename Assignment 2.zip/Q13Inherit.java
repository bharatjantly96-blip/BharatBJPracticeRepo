package assignment;

class Device{
	void start()
	{
		System.out.println("Device");
	}
}

class Mobile extends Device {
	void calling()
	{
		System.out.println("Mobile");
	}
}

class SmartPhone extends Mobile{
	void internet()
	{
		System.out.println("SmartPhone");
	}
  }

public class Q13Inherit {

	public static void main(String[] args) {
	
		SmartPhone sm = new SmartPhone();
		sm.internet();
		sm.calling();
		sm.start();
	}

}
