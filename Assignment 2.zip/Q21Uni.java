package assignment;

class University{
	static String country = "India";
	String universityName;
	
	University(String universityName)
	{
		this.universityName= universityName;
	}
	
	void display()
	{
		System.out.println("Country: "+country);
		System.out.println("University: "+universityName);
		System.out.println("_______________");
		
	}
	
}

public class Q21Uni {

	public static void main(String[] args) {
		
		University uni = new University("NIT");
		University uni1 = new University("IIT");
	    uni.display();
	    uni1.display();

	}

}
