package assignment;

class Hospital
{
	void emergencyService()
	{
		System.out.println("Emergency services");
	}
}

class CityHospital extends Hospital
{
	
	void emergencyService()
	{
		super.emergencyService();
		System.out.println("Emergency services from City Hospital");
	}
}

public class Q16Hospital {

	public static void main(String[] args) {
	
		CityHospital ch = new CityHospital();
		ch.emergencyService();
	}

}
