package assignment;

class Vehicle 
{
	void fuelType() 
	{	
		System.out.println("Runs on fuel");	
	}
}

class ElectricCar extends Vehicle
{
	void fuelType()
	{
		System.out.println("Runs on electricity");
	}
}

public class Q2Vehicle {
		
	public static void main(String[] args) {
		
		Vehicle obj = new Vehicle();
		obj.fuelType();
		
		ElectricCar obj1 = new ElectricCar();
		obj1.fuelType();

	}

}
