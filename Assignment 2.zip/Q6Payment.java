package assignment;

interface Payment
{
	void makePayment();
}

class UPI implements Payment
{
	public void makePayment() 
	{
		System.out.println("This is UPI payment");
	}
}

class CreditCard implements Payment
{
	public void makePayment()
	{
		System.out.println("This is CreditCard payment");
	}
}

public class Q6Payment {

	public static void main(String[] args) {
	
		Payment pay = new UPI();
		pay.makePayment();
		
		Payment pay1 = new CreditCard();
		pay1.makePayment();

	}

}
