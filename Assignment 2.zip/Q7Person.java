package assignment;

class Person{
	
	Person()
	{
		System.out.println("Person Created");
	}
}

class Student extends Person
{
	Student()
	{
		super();
		System.out.println("Student Created");
	}
}

public class Q7Person {

	public static void main(String[] args) {
		
		Student st = new Student();
		
	}
}
